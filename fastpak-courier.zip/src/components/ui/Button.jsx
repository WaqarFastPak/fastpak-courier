import React from 'react'
export function Button({variant='primary', className='', asChild=false, children, ...props}){
  const cls = `btn ${variant==='secondary'?'btn-secondary':'btn-primary'} ${className}`
  if(asChild) return React.cloneElement(children, { className: `${children.props.className||''} ${cls}` })
  return <button className={cls} {...props}>{children}</button>
}
