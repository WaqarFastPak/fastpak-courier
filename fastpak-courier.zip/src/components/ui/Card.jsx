export function Card({className='', children}){ return <div className={`card ${className}`}>{children}</div> }
export function CardHeader({children}){ return <div className="card-section border-b">{children}</div> }
export function CardContent({children}){ return <div className="card-section">{children}</div> }
export function CardTitle({children, className=''}){ return <h3 className={`font-semibold ${className}`}>{children}</h3> }
