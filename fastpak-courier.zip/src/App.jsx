
import React, { useState } from "react";
import { Routes, Route, Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Package2, HandCoins, Truck, MapPin, Users, Phone, Shield, Calculator, Globe2, Sparkles, Menu, X, CheckCircle2, MessageSquareText } from "lucide-react";
import { ResponsiveContainer, LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip } from "recharts";

import { Button } from "./components/ui/Button.jsx";
import { Card, CardContent, CardHeader, CardTitle } from "./components/ui/Card.jsx";
import Input from "./components/ui/Input.jsx";
import Badge from "./components/ui/Badge.jsx";

const CITIES = ["Karachi","Lahore","Islamabad","Rawalpindi","Faisalabad","Multan","Peshawar","Quetta","Hyderabad","Sialkot"];
const CITY_ZONE = {Karachi:"South",Hyderabad:"South",Lahore:"Central",Islamabad:"North",Rawalpindi:"North",Faisalabad:"Central",Multan:"Central",Sialkot:"Central",Peshawar:"North",Quetta:"North"};
const ZONES = { WITHIN_CITY: "within_city", WITHIN_ZONE: "within_zone", ACROSS_PAK: "across_pak" };
const BASE_RATES = {
  [ZONES.WITHIN_CITY]: { upto1kg: 200, addkg: 70 },
  [ZONES.WITHIN_ZONE]: { upto1kg: 260, addkg: 90 },
  [ZONES.ACROSS_PAK]: { upto1kg: 320, addkg: 110 },
};
const FUEL_SURCHARGE = 0.07;
const COD_FEE_RATE = 0.015;

const mockRTOTrend = [
  { month: "Jan", rto: 12 }, { month: "Feb", rto: 11 }, { month: "Mar", rto: 10 }, { month: "Apr", rto: 9.5 },
  { month: "May", rto: 9.2 }, { month: "Jun", rto: 8.9 }, { month: "Jul", rto: 8.7 }, { month: "Aug", rto: 8.5 },
];

function getZone(o,d){ if(!o||!d) return ZONES.ACROSS_PAK; if(o===d) return ZONES.WITHIN_CITY; return CITY_ZONE[o]===CITY_ZONE[d]?ZONES.WITHIN_ZONE:ZONES.ACROSS_PAK; }
function calcRate({origin,destination,weight,codAmount}){
  const zone = getZone(origin,destination);
  const base = BASE_RATES[zone];
  const kg = Math.max(0.5, weight);
  const baseCost = base.upto1kg + (Math.ceil(Math.max(0, kg - 1)) * base.addkg);
  const fuel = baseCost * FUEL_SURCHARGE;
  const codFee = (codAmount||0) * COD_FEE_RATE;
  const total = Math.round(baseCost + fuel + codFee);
  return { zone, baseCost: Math.round(baseCost), fuel: Math.round(fuel), codFee: Math.round(codFee), total };
}

const strings = {
  en: {
    brand: "FASTPAK Courier",
    tagline: "Fast & Reliable COD Across Pakistan",
    cta_signup: "Open a Merchant Account",
    cta_pickup: "Book a Pickup",
    nav: { home:"Home", services:"Services", pricing:"Pricing", tracking:"Tracking", business:"For Businesses", contact:"Contact" },
    heroPoints: ["Nationwide COD & Overnight","Low RTO with smart reattempts","Weekly payouts with transparent ledger"],
    features: { cod:"Cash on Delivery", tracking:"Real-time Tracking", api:"API & eCom Integrations", coverage:"Nationwide Coverage", safety:"Rider Safety First", support:"WhatsApp-first Support" },
    servicesHead: "What we deliver",
    pricingHead: "Simple, transparent pricing",
    calcHead: "Instant Rate Calculator",
    origin: "Origin City", destination: "Destination City", weight: "Weight (kg)", codAmount: "COD Amount (PKR)", getRate: "Get Rate", yourRate: "Your Rate",
    zoneLabels: { within_city: "Within City", within_zone: "Within Zone", across_pak: "Across Pakistan" },
    trackingHead: "Track your shipment", enterTracking: "Enter tracking ID (e.g., FP123456)", trackNow: "Track Now", mockStatus: "Demo data shown. Connect your live tracking API.",
    businessHead: "Built for Pakistani sellers",
    highlights: ["Bulk upload via CSV/Excel","Shopify & WooCommerce plugins","JR/DRP automated reattempt flow","Cash reconciliation & T+7 payouts","Nadra-verified riders & insurance"],
    contactHead: "Let’s talk", hotline: "Helpline", address: "Head Office", message: "Your Message", send: "Send Message", lang: "اردو",
  },
  ur: {
    brand: "فاسٹ پیک کورئیر",
    tagline: "پاکستان بھر میں تیز اور قابلِ اعتماد COD سروس (FASTPAK)",
    cta_signup: "مرچنٹ اکاؤنٹ کھولیں", cta_pickup: "پِک اَپ بک کریں",
    nav: { home:"ہوم", services:"سروسز", pricing:"پرائسنگ", tracking:"ٹرَیکنگ", business:"بزنس کے لیے", contact:"رابطہ" },
    heroPoints: ["نیشن وائیڈ COD اور اوورنائٹ","کم RTO اسمارٹ ری اٹمپٹس کے ساتھ","ہفتہ وار ادائیگیاں شفاف لیجر کے ساتھ"],
    features: { cod:"کیَش آن ڈیلیوری", tracking:"رِیئل ٹائم ٹرَیکنگ", api:"API اور ای کوم انٹیگریشنز", coverage:"پاکستان بھر میں کوریج", safety:"رائیڈر سَیفٹی پہلے", support:"واٹس ایپ فرسٹ سپورٹ" },
    servicesHead: "ہم کیا ڈیلیور کرتے ہیں", pricingHead: "سادہ اور شفاف پرائسنگ", calcHead: "انسٹنٹ ریٹ کیلکولیٹر",
    origin:"اوریجن شہر", destination:"ڈیسی نیشن شہر", weight:"وزن (کلو)", codAmount:"COD رقم (روپے)", getRate:"ریٹ حاصل کریں", yourRate:"آپ کا ریٹ",
    zoneLabels: { within_city:"وِد اِن سِٹی", within_zone:"وِد اِن زون", across_pak:"اکراس پاکستان" },
    trackingHead:"اپنی شپمنٹ ٹرَیک کریں", enterTracking:"ٹرَیکنگ آئی ڈی درج کریں (مثال: FP123456)", trackNow:"ابھی ٹرَیک کریں", mockStatus:"ڈیمو ڈیٹا نظر آ رہا ہے۔ اپنی لائیو API کنیکٹ کریں۔",
    businessHead:"پاکستانی سیلرز کے لیے تیار", highlights:["CSV/Excel کے ذریعے بلک اپ لوڈ","Shopify اور WooCommerce پلگ اِنز","JR/DRP آٹو ری اٹمپٹ فلو","کیش ریکنسلی ایشن اور T+7 پی آؤٹس","نادرا ویریفائیڈ رائیڈرز اور انشورنس"],
    contactHead:"بات چیت کریں", hotline:"ہیلپ لائن", address:"ہیڈ آفس", message:"آپ کا پیغام", send:"پیغام بھیجیں", lang:"EN"
  },
};

function useI18n(){
  const [lang, setLang] = useState("en");
  const t = strings[lang];
  return { t, lang, setLang };
}

function Container({children}){ return <div className="container">{children}</div> }

function Nav({ lang, setLang }){
  const t = strings[lang];
  const [open,setOpen]=useState(false);
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-white/70 backdrop-blur">
      <Container>
        <div className="flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Package2 className="h-7 w-7"/><span className="font-bold text-xl tracking-tight">{t.brand}</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <NavLinks t={t} />
          </nav>
          <div className="hidden md:flex items-center gap-2">
            <Button variant="secondary" asChild><Link to="/business">{t.cta_signup}</Link></Button>
            <Button asChild><Link to="/tracking">{t.cta_pickup}</Link></Button>
            <button className="btn" onClick={()=>setLang(lang==="en"?"ur":"en")}>{t.lang}</button>
          </div>
          <button className="md:hidden btn" onClick={()=>setOpen(v=>!v)}>{open?<X/>:<Menu/>}</button>
        </div>
        {open && (
          <div className="md:hidden py-4 flex flex-col gap-3">
            <NavLinks t={t} mobile onClick={()=>setOpen(false)}/>
            <div className="flex gap-2">
              <Button variant="secondary" asChild><Link to="/business">{t.cta_signup}</Link></Button>
              <Button asChild><Link to="/tracking">{t.cta_pickup}</Link></Button>
              <button className="btn" onClick={()=>setLang(lang==="en"?"ur":"en")}>{t.lang}</button>
            </div>
          </div>
        )}
      </Container>
    </header>
  )
}

function NavLinks({ t, onClick, mobile }){
  const links = [{to:"/",label:t.nav.home},{to:"/services",label:t.nav.services},{to:"/pricing",label:t.nav.pricing},{to:"/tracking",label:t.nav.tracking},{to:"/business",label:t.nav.business},{to:"/contact",label:t.nav.contact}];
  return <>{links.map(l=>(<Link key={l.to} to={l.to} onClick={onClick} className={`${mobile?"py-2":""} text-sm hover:opacity-80`}>{l.label}</Link>))}</>
}

function Footer({ t }){
  return (
    <footer className="mt-24 border-t py-10 text-sm bg-gray-50">
      <Container>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Package2 className="h-6 w-6"/><span className="font-semibold">{t.brand}</span>
            </div>
            <p className="text-gray-600">{t.tagline}</p>
            <div className="mt-4 flex items-center gap-2">
              <Badge>ISO 9001</Badge>
              <Badge><Shield className="h-3 w-3"/>Rider Safety</Badge>
              <Badge><Globe2 className="h-3 w-3"/>PK Nationwide</Badge>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-3">{t.nav.services}</h4>
            <ul className="space-y-2 text-gray-600">
              <li>COD & Reconciliation</li><li>Same-day (select cities)</li><li>Overnight</li><li>Returns (RTO/RTS)</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-3">{t.nav.pricing}</h4>
            <ul className="space-y-2 text-gray-600"><li>Within City</li><li>Within Zone</li><li>Across Pakistan</li></ul>
          </div>
          <div>
            <h4 className="font-semibold mb-3">{t.nav.contact}</h4>
            <p className="text-gray-600">support@fastpak.pk</p>
            <p className="text-gray-600">{t.hotline}: 021-111-000-123</p>
            <p className="text-gray-600">{t.address}: Shahrah-e-Faisal, Karachi</p>
          </div>
        </div>
        <div className="mt-8 text-gray-500 text-xs">© {new Date().getFullYear()} {t.brand}. All rights reserved.</div>
      </Container>
    </footer>
  )
}

function Home({ t }){
  const points = t.heroPoints;
  return (<>
    <section className="bg-gradient-to-b from-white to-gray-50">
      <Container>
        <div className="py-20 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <div>
            <motion.h1 initial={{y:10,opacity:0}} animate={{y:0,opacity:1}} transition={{duration:0.5}} className="text-4xl md:text-5xl font-extrabold leading-tight">{t.tagline}</motion.h1>
            <p className="mt-4 text-gray-600">Grow your ecommerce with a courier built for Pakistani sellers. Transparent pricing, reliable tracking, and fast COD settlements.</p>
            <div className="mt-6 flex items-center gap-3">
              <Button asChild><Link to="/business" className="flex items-center gap-2">{t.cta_signup} <ArrowRight className="h-4 w-4"/></Link></Button>
              <Button variant="secondary" asChild><Link to="/pricing" className="flex items-center gap-2">{t.nav.pricing} <Calculator className="h-4 w-4"/></Link></Button>
            </div>
            <ul className="mt-6 space-y-2">
              {points.map(p=>(<li key={p} className="flex items-start gap-2"><CheckCircle2 className="mt-1 h-5 w-5"/><span>{p}</span></li>))}
            </ul>
          </div>
          <div>
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5"/>Trust at a glance</CardTitle></CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <Stat label="On-time" value="96.8%"/><Stat label="RTO" value="8.5%"/><Stat label="Cities" value="850+"/><Stat label="Riders" value="2,000+"/>
                </div>
                <div className="mt-6 h-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={mockRTOTrend} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" /><YAxis unit="%" /><Tooltip /><Line type="monotone" dataKey="rto" dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </Container>
    </section>

    <section className="py-16">
      <Container>
        <h2 className="text-2xl md:text-3xl font-bold mb-8">{t.servicesHead}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Feature icon={<HandCoins/>} title={t.features.cod} desc="COD with T+7 reconciliations, partial collection, and doorstep verification." />
          <Feature icon={<Truck/>} title="Same Day / Overnight" desc="Fast lanes in major metros. Smart routing reduces delays and RTO." />
          <Feature icon={<MapPin/>} title={t.features.coverage} desc="Coverage across Pakistan with partner hubs and vetted linehaul." />
          <Feature icon={<Shield/>} title={t.features.safety} desc="Nadra-verified riders, shipment insurance, and safety protocols." />
          <Feature icon={<Users/>} title="Merchant Panel" desc="Bulk upload, API keys, reattempt logic, and ledger downloads." />
          <Feature icon={<MessageSquareText/>} title={t.features.support} desc="WhatsApp-first support with proactive status notifications." />
        </div>
      </Container>
    </section>
  </>)
}

function Stat({label,value}){ return <div className="rounded-2xl border p-4 text-center"><div className="text-2xl font-bold">{value}</div><div className="text-xs uppercase tracking-wide text-gray-500">{label}</div></div> }
function Feature({icon,title,desc}){
  return (<Card><CardHeader><CardTitle className="flex items-center gap-2">{icon}<span>{title}</span></CardTitle></CardHeader><CardContent><p className="text-gray-600">{desc}</p></CardContent></Card>)
}

function Services({ t }){
  const items=[
    {icon:<HandCoins/>, title:t.features.cod, pts:["Doorstep cash collection","Partial payment option","Secure vaulting & deposit"]},
    {icon:<Truck/>, title:"Same Day / Overnight", pts:["Metro-to-metro priority","Late pickup windows","Air/Linehaul optimized"]},
    {icon:<MapPin/>, title:t.features.coverage, pts:["850+ destination cities","COD + Prepaid","Return to seller (RTO/RTS)"]},
    {icon:<Shield/>, title:t.features.safety, pts:["Nadra-verified riders","Insurance","Geo-fenced routes"]},
    {icon:<Users/>, title:"Merchant Panel", pts:["CSV/Excel bulk upload","Order tracking & webhooks","T+7 payouts & ledger"]},
    {icon:<Globe2/>, title:t.features.api, pts:["REST API","Shopify/WooCommerce plugins","Sandbox keys"]},
  ];
  return (<Container><div className="py-12"><h1 className="text-3xl font-bold mb-8">{t.nav.services}</h1><div className="grid grid-cols-1 md:grid-cols-3 gap-6">
    {items.map(it=>(<Card key={it.title}><CardHeader><CardTitle className="flex items-center gap-2">{it.icon}<span>{it.title}</span></CardTitle></CardHeader><CardContent><ul className="space-y-2 text-gray-700">{it.pts.map(p=>(<li key={p} className="flex items-start gap-2"><CheckCircle2 className="mt-1 h-4 w-4"/>{p}</li>))}</ul></CardContent></Card>))}
  </div></div></Container>)
}

function Pricing({ t }){
  return (<Container><div className="py-12">
    <h1 className="text-3xl font-bold mb-8">{t.pricingHead}</h1>
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <Card><CardHeader><CardTitle className="flex items-center gap-2"><Calculator className="h-5 w-5"/>{t.calcHead}</CardTitle></CardHeader><CardContent><RateCalculator t={t}/></CardContent></Card>
      <Card><CardHeader><CardTitle>Reference Table</CardTitle></CardHeader><CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-left"><th className="py-2">Zone</th><th>Up to 1kg</th><th>+1kg</th><th>Fuel</th><th>COD Fee</th></tr></thead>
            <tbody>
              <tr><td>{t.zoneLabels.within_city}</td><td>PKR {BASE_RATES[ZONES.WITHIN_CITY].upto1kg}</td><td>PKR {BASE_RATES[ZONES.WITHIN_CITY].addkg}</td><td>{Math.round(FUEL_SURCHARGE*100)}%</td><td>{Math.round(COD_FEE_RATE*1000)/10}%</td></tr>
              <tr><td>{t.zoneLabels.within_zone}</td><td>PKR {BASE_RATES[ZONES.WITHIN_ZONE].upto1kg}</td><td>PKR {BASE_RATES[ZONES.WITHIN_ZONE].addkg}</td><td>{Math.round(FUEL_SURCHARGE*100)}%</td><td>{Math.round(COD_FEE_RATE*1000)/10}%</td></tr>
              <tr><td>{t.zoneLabels.across_pak}</td><td>PKR {BASE_RATES[ZONES.ACROSS_PAK].upto1kg}</td><td>PKR {BASE_RATES[ZONES.ACROSS_PAK].addkg}</td><td>{Math.round(FUEL_SURCHARGE*100)}%</td><td>{Math.round(COD_FEE_RATE*1000)/10}%</td></tr>
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-gray-500">*Placeholders. Update to your live tariff.</p>
      </CardContent></Card>
    </div>
  </div></Container>)
}

function RateCalculator({ t }){
  const [origin,setOrigin]=useState("Karachi");
  const [destination,setDestination]=useState("Lahore");
  const [weight,setWeight]=useState(1);
  const [codAmount,setCodAmount]=useState(2000);
  const [result,setResult]=useState(null);
  return (<div className="space-y-4">
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div><label className="text-xs text-gray-500">{t.origin}</label>
        <select className="input" value={origin} onChange={e=>setOrigin(e.target.value)}>{CITIES.map(c=><option key={c} value={c}>{c}</option>)}</select>
      </div>
      <div><label className="text-xs text-gray-500">{t.destination}</label>
        <select className="input" value={destination} onChange={e=>setDestination(e.target.value)}>{CITIES.map(c=><option key={c} value={c}>{c}</option>)}</select>
      </div>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div><label className="text-xs text-gray-500">{t.weight}</label><Input type="number" min="0.5" step="0.5" value={weight} onChange={e=>setWeight(e.target.value)} /></div>
      <div><label className="text-xs text-gray-500">{t.codAmount}</label><Input type="number" min="0" step="100" value={codAmount} onChange={e=>setCodAmount(e.target.value)} /></div>
    </div>
    <Button onClick={()=>setResult(calcRate({origin,destination,weight:Number(weight),codAmount:Number(codAmount)}))}>{t.getRate}</Button>
    {result && (<motion.div initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} className="rounded-2xl border p-4">
      <div className="flex items-center justify-between"><div className="font-semibold">{t.yourRate}</div><Badge>{t.zoneLabels[result.zone]}</Badge></div>
      <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
        <SummaryItem label="Base" value={`PKR ${result.baseCost}`} /><SummaryItem label="Fuel" value={`PKR ${result.fuel}`} /><SummaryItem label="COD Fee" value={`PKR ${result.codFee}`} /><SummaryItem label="Total" value={`PKR ${result.total}`} bold />
      </div>
    </motion.div>)}
  </div>)
}
function SummaryItem({label,value,bold}){ return (<div className="rounded-xl border p-3"><div className="text-xs text-gray-500">{label}</div><div className={`mt-1 ${bold?'font-bold':''}`}>{value}</div></div>) }

function Tracking({ t }){
  const [tid,setTid]=useState("");
  const [info,setInfo]=useState(null);
  const onTrack=()=>{
    const mock={ id: tid || "FP123456", status:"In Transit", history:[
      { time:"2025-08-22 10:05", msg:"Picked up from shipper" },
      { time:"2025-08-23 09:30", msg:"Departed Karachi Hub" },
      { time:"2025-08-24 13:15", msg:"Arrived Lahore Hub" },
    ], eta:"2025-08-25", consignee:"Ali Raza", cod:2499 };
    setInfo(mock);
  };
  return (<Container><div className="py-12">
    <h1 className="text-3xl font-bold mb-6">{t.trackingHead}</h1>
    <div className="flex items-center gap-2">
      <Input placeholder={t.enterTracking} value={tid} onChange={e=>setTid(e.target.value)} />
      <Button onClick={onTrack}>{t.trackNow}</Button>
    </div>
    <p className="mt-2 text-xs text-gray-500">{t.mockStatus}</p>
    {info && (<Card className="mt-6"><CardHeader><CardTitle className="flex items-center gap-2"><Package2 className="h-5 w-5"/>#{info.id}</CardTitle></CardHeader><CardContent>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2"><ul className="space-y-3">{info.history.map((h,i)=>(<li key={i} className="rounded-xl border p-3 flex items-start gap-3"><Badge>{h.time}</Badge><span>{h.msg}</span></li>))}</ul></div>
        <div className="space-y-2 text-sm">
          <SummaryItem label="Status" value={info.status}/>
          <SummaryItem label="ETA" value={info.eta}/>
          <SummaryItem label="Consignee" value={info.consignee}/>
          <SummaryItem label="COD" value={`PKR ${info.cod}`}/>
        </div>
      </div>
    </CardContent></Card>)}
  </div></Container>)
}

function Business({ t }){
  const [tab,setTab]=useState("signup");
  return (<Container><div className="py-12">
    <h1 className="text-3xl font-bold mb-2">{t.businessHead}</h1>
    <p className="text-gray-600 mb-6">Create a free merchant account, start shipping today, and get weekly COD settlements into your bank account.</p>
    <div className="w-full">
      <div className="grid grid-cols-2 w-full border rounded-2xl overflow-hidden">
        <button className={`py-2 ${tab==='signup'?'bg-black text-white':''}`} onClick={()=>setTab('signup')}>Sign Up</button>
        <button className={`py-2 ${tab==='features'?'bg-black text-white':''}`} onClick={()=>setTab('features')}>Features</button>
      </div>
      {tab==='signup' ? (<div className="mt-6"><Card><CardHeader><CardTitle>Open a Merchant Account</CardTitle></CardHeader><CardContent><SignupForm/></CardContent></Card></div>)
      : (<div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <Feature icon={<Calculator/>} title="Smart Rate Cards" desc="Auto-zone detection, fuel surcharge, and COD fee caps."/>
          <Feature icon={<Shield/>} title="Fraud Controls" desc="Blacklist engine, OTP on delivery, and address verification."/>
          <Feature icon={<Users/>} title="Team Access" desc="Roles, permissions, and activity logs for your staff."/>
          <Feature icon={<MessageSquareText/>} title="Webhooks" desc="Live status updates to your store and CRM."/>
        </div>)}
    </div>
  </div></Container>)
}

function SignupForm(){
  const [state,setState]=useState({ name:'', phone:'', email:'', store:'', city:'Karachi' });
  const submit=(e)=>{ e.preventDefault(); alert(`Thanks ${state.name}! Our team will reach out at ${state.phone}. (Replace with your API call)`) }
  return (<form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
    <div><label className="text-xs text-gray-500">Business / Store Name</label><Input value={state.store} onChange={e=>setState({...state,store:e.target.value})} required/></div>
    <div><label className="text-xs text-gray-500">Contact Person</label><Input value={state.name} onChange={e=>setState({...state,name:e.target.value})} required/></div>
    <div><label className="text-xs text-gray-500">Phone (WhatsApp)</label><Input value={state.phone} onChange={e=>setState({...state,phone:e.target.value})} required/></div>
    <div><label className="text-xs text-gray-500">Email</label><Input type="email" value={state.email} onChange={e=>setState({...state,email:e.target.value})}/></div>
    <div className="md:col-span-2"><label className="text-xs text-gray-500">City</label><select className="input" value={state.city} onChange={e=>setState({...state,city:e.target.value})}>{CITIES.map(c=><option key={c} value={c}>{c}</option>)}</select></div>
    <div className="md:col-span-2"><Button type="submit" className="w-full">Create Account</Button></div>
    <p className="md:col-span-2 text-xs text-gray-500">By creating an account, you agree to our Terms and Privacy Policy.</p>
  </form>)
}

function Contact({ t }){
  return (<Container><div className="py-12">
    <h1 className="text-3xl font-bold mb-6">{t.contactHead}</h1>
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <Card><CardHeader><CardTitle>Say hello</CardTitle></CardHeader><CardContent><ContactForm t={t}/></CardContent></Card>
      <Card><CardHeader><CardTitle>Reach us</CardTitle></CardHeader><CardContent>
        <ul className="space-y-2 text-gray-700">
          <li className="flex items-center gap-2"><Phone className="h-4 w-4"/> {t.hotline}: 021-111-000-123</li>
          <li>Email: support@fastpak.pk</li>
          <li>{t.address}: Shahrah-e-Faisal, Karachi</li>
          <li>WhatsApp: +92 300 1234567</li>
        </ul>
        <div className="mt-4 rounded-xl border p-4 text-sm">Google Map placeholder — embed your live map iframe here.</div>
      </CardContent></Card>
    </div>
  </div></Container>)
}
function ContactForm({ t }){
  const [state,setState]=useState({name:'',email:'',message:''});
  const submit=(e)=>{ e.preventDefault(); alert(`Thanks ${state.name}! We'll reply at ${state.email}.`) }
  return (<form onSubmit={submit} className="space-y-3">
    <div><label className="text-xs text-gray-500">Name</label><Input value={state.name} onChange={e=>setState({...state,name:e.target.value})} required/></div>
    <div><label className="text-xs text-gray-500">Email</label><Input type="email" value={state.email} onChange={e=>setState({...state,email:e.target.value})}/></div>
    <div><label className="text-xs text-gray-500">{t.message}</label><textarea value={state.message} onChange={e=>setState({...state,message:e.target.value})} className="w-full border rounded-md p-2 min-h-[120px]"/></div>
    <Button type="submit">{t.send}</Button>
  </form>)
}

function PageWrapper({ children }){
  const location = useLocation();
  return (<AnimatePresence mode="wait">
    <motion.main key={location.pathname} initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-10}} transition={{duration:0.2}}>
      {children}
    </motion.main>
  </AnimatePresence>)
}

export default function App(){
  const {t,lang,setLang} = useI18n();
  return (<div className="min-h-screen bg-white text-neutral-900">
    <Nav lang={lang} setLang={setLang} />
    <PageWrapper>
      <Routes>
        <Route path="/" element={<Home t={t}/>}/>
        <Route path="/services" element={<Services t={t}/>}/>
        <Route path="/pricing" element={<Pricing t={t}/>}/>
        <Route path="/tracking" element={<Tracking t={t}/>}/>
        <Route path="/business" element={<Business t={t}/>}/>
        <Route path="/contact" element={<Contact t={t}/>}/>
      </Routes>
    </PageWrapper>
    <Footer t={t} />
  </div>)
}
